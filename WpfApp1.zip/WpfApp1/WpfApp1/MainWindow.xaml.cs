﻿using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using static System.Array;
using System.Collections.Generic;
using System.Linq;
using System.Collections;

namespace WpfApp1
{
    public partial class MainWindow : Window
    {
        public struct Person
        {
            public int Id { get; set; }
            public string Name { get; set; }
            public int Age { get; set; }
        }

        private List<Person> people = new List<Person>();
        private string[] searchOptions = { "Search by Age", "Search by Name" };

        public MainWindow()
        {
            InitializeComponent();
            cboSearchBy.ItemsSource = searchOptions;
        }

        public List<Person> People { get { return people; } }

        private void btnAdd_Click(object sender, RoutedEventArgs e)
        {
            int age;
            if (!int.TryParse(txtAge.Text, out age))
            {
                MessageBox.Show("Invalid age format.");
                return;
            }

            people.Add(new Person { Id = people.Count + 1, Name = txtName.Text, Age = age });
            txtName.Clear();
            txtAge.Clear();
        }

        private void btnSortAge_Click(object sender, RoutedEventArgs e)
        {
            SortPeople(p => p.Age);
            PrintPeople(); 
        }

        private void btnSortName_Click(object sender, RoutedEventArgs e)
        {
            SortPeople(p => p.Name);
            PrintPeople(); 
        }

        private void SortPeople(Func<Person, object> sortExpression)
        {
           
            for (int i = 0; i < people.Count - 1; i++)
            {
                for (int j = 0; j < people.Count - i - 1; j++) 
                {
                    if (Comparer.Default.Compare(sortExpression(people[j]), sortExpression(people[j + 1])) > 0)
                    {
                        Person temp = people[j];
                        people[j] = people[j + 1];
                        people[j + 1] = temp;
                    }
                }
            }
        }

        private void btnSearch_Click(object sender, RoutedEventArgs e)
        {
            int searchIndex = cboSearchBy.SelectedIndex;
            string searchTerm = txtSearch.Text;

            if (searchIndex == 0) 
            {
                int searchAge;
                if (!int.TryParse(searchTerm, out searchAge))
                {
                    MessageBox.Show("Invalid age format for search.");
                    return;
                }
                List<Person> results = people.Where(p => p.Age == searchAge).ToList();
                if (results.Count == 0)
                {
                    MessageBox.Show("No person found with that age.");
                }
                else
                {
                    PrintPeople(results);
                }
            }
            else if (searchIndex == 1) 
            {
                List<Person> results = people.Where(p => p.Name.Contains(searchTerm)).ToList();
                if (results.Count == 0)
                {
                    MessageBox.Show("No person found with that name.");
                }
                else
                {
                    PrintPeople(results); 
                }
            }
        }

        private void PrintPeople(List<Person> peopleToPrint = null)
        {
            if (peopleToPrint == null)
            {
                peopleToPrint = people;
            }

            StringBuilder output = new StringBuilder(); 
            output.AppendLine("People:");
            foreach (Person person in peopleToPrint)
            {
                output.AppendLine($"Id: {person.Id}, Name: {person.Name}, Age: {person.Age}");
            }

            txtPrintResults.Text = output.ToString(); 
        }

        private void btnRemove_Click(object sender, RoutedEventArgs e)
        {
            int removeId;
            if (!int.TryParse(txtRemoveId.Text, out removeId))
            {
                MessageBox.Show("Invalid ID format. Please enter a valid integer.");
                return; 
            }

            int indexToRemove = people.FindIndex(p => p.Id == removeId);

            if (indexToRemove == -1)
            {
                MessageBox.Show("No person found with that ID.");
            }
            else
            {
                people.RemoveAt(indexToRemove);
                MessageBox.Show("Person removed successfully.");
                PrintPeople();
            }
        }
    }
}
